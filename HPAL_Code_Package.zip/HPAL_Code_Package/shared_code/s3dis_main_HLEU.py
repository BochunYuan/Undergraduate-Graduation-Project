import argparse
import json
import os
from os.path import exists

import numpy as np
import random
import gc
import warnings
import concurrent.futures
import threading
import sys
import io
import multiprocessing as mp

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
LOCAL_TORCHSPARSE_ROOT = os.path.join(PROJECT_ROOT, 'torchsparse')
if LOCAL_TORCHSPARSE_ROOT not in sys.path:
    sys.path.insert(0, LOCAL_TORCHSPARSE_ROOT)

try:
    import torch
    TORCH_LIB_DIR = os.path.join(os.path.dirname(torch.__file__), 'lib')
    if os.path.isdir(TORCH_LIB_DIR):
        cur_ld_library_path = os.environ.get('LD_LIBRARY_PATH', '')
        ld_paths = [p for p in cur_ld_library_path.split(':') if p]
        if TORCH_LIB_DIR not in ld_paths:
            os.environ['LD_LIBRARY_PATH'] = (
                TORCH_LIB_DIR if not cur_ld_library_path
                else TORCH_LIB_DIR + ':' + cur_ld_library_path
            )
except Exception:
    pass

try:
    from blinker import Signal
except ModuleNotFoundError:
    class Signal:
        """Minimal fallback used when blinker is unavailable."""

        def __init__(self):
            self._receivers = []

        def connect(self, receiver):
            self._receivers.append(receiver)

        def send(self, *args, **kwargs):
            for receiver in list(self._receivers):
                receiver(*args, **kwargs)

from active_func_HLEU import generate_score, active_chose
from Mink.dataloader.dataset import Stanford3DDataset
from config import ConfigS3DIS as cfg
from helper_utils import log_out
from data_base_HLEU import S3DIS
from HierarchicalMatrixReader import HierarchicalMatrixReader

os.environ['CUDA_VISIBLE_DEVICES'] = str(cfg.gpu)
import torch
from Mink.base_agent_HLEU import BaseTrainer as minkNet

# 创建信号
output_signal = Signal()

# 保存原始的 sys.stdout
original_stdout = sys.stdout
os.makedirs(os.path.dirname(cfg.saving_path)) if not exists(os.path.dirname(cfg.saving_path)) else None
Log_file = open(cfg.saving_path + '.txt', 'a')

# 订阅信号的槽函数，统一处理输出
def handle_output(message):
    # 使用原始的 sys.stdout 进行输出，避免再次触发拦截器
    original_stdout.write(message)
    Log_file.write(message)
    Log_file.flush()

# 将槽函数连接到信号
output_signal.connect(handle_output)

# 自定义类，用于全局拦截输出并通过信号转发
class GlobalOutputInterceptor(io.StringIO):
    def write(self, message):
        # 通过信号发送消息，交由主线程处理
        output_signal.send(message)

# 重定向 sys.stdout
sys.stdout = GlobalOutputInterceptor()
# 重定向 sys.stderr
sys.stderr = GlobalOutputInterceptor()

warnings.filterwarnings('ignore')
np.seterr(all='ignore')
np.random.seed(1)
random.seed(1)
torch.manual_seed(7122)
# torch.cuda.set_per_process_memory_fraction(0.50, 0)


def mk_dirs():
    os.makedirs(cfg.base_path) if not exists(cfg.base_path) else None
    os.mkdir(cfg.model_save_dir_student) if not exists(cfg.model_save_dir_student) else None
    os.mkdir(cfg.model_save_dir_teacher) if not exists(cfg.model_save_dir_teacher) else None
    os.mkdir(cfg.labeled_save_path) if not exists(cfg.labeled_save_path) else None
    os.mkdir(cfg.save_path_feat) if not exists(cfg.save_path_feat) else None
    os.mkdir(cfg.save_path_probs) if not exists(cfg.save_path_probs) else None


def train_fullsupervised():
    """
    Fully supervised baseline
    """
    model_mink = minkNet(cfg, Log_file, dataset)

    # Fully Supervised baseline with 100% labeled data(upperbound)
    train_dataset = Stanford3DDataset(dataset.input_xyz['train'], dataset.input_colors['train'],
                                      dataset.input_labels['train'], dataset.input_names['train'],
                                      voxel_size=0.05)

    # Fully Supervised baseline with sparsely labeled Data
    # train_dataset = Stanford3DDataset(dataset.input_xyz['train'], dataset.input_colors['train'],
    #                                         dataset.input_labels['train'], dataset.input_names['train'],
    #                                         labeled_points=dataset.labeled_points, voxel_size=0.05)

    val_dataset = Stanford3DDataset(dataset.input_xyz['validation'], dataset.input_colors['validation'],
                                    dataset.input_labels['validation'], dataset.input_names['validation'],
                                    voxel_size=0.05)

    model_mink.train_SGD(train_dataset, val_dataset)

def train_model_process(i, model_student, train_dataset, val_dataset, model_teacher, iteration):
    model_student[i].train_consistencyguide_semi_SGD(train_dataset[i], val_dataset[i], model_teacher[i], iteration)

def train_HPAL():
    """
    our method: HPAL(Hierarchy Point-based Active Learning)
    """

    train_dataset = []
    val_dataset = []
    for i in range(cfg.label_level):
        train_dataset.append(Stanford3DDataset(dataset[i].input_xyz['train'], dataset[i].input_colors['train'],
                                               dataset[i].input_labels['train'], dataset[i].input_names['train'],
                                               labeled_points=dataset[i].labeled_points, voxel_size=0.05))
        val_dataset.append(Stanford3DDataset(dataset[i].input_xyz['validation'], dataset[i].input_colors['validation'],
                                             dataset[i].input_labels['validation'], dataset[i].input_names['validation'],
                                             voxel_size=0.05))
    
    print('All dataset loaded')

    # saving labeled data
    save_path_curlabeled = os.path.join(cfg.labeled_save_path, 'labeled_data_' + str(cfg.al_iter) + '.json')
    f1 = open(save_path_curlabeled, 'w')
    json.dump(dataset[0].labeled_points, f1)
    f1.close()
    print('Labelled points saved')

    if cfg.al_iter == 0:
        for i in range(cfg.label_level):
            model_teacher[i].net.load_state_dict(model_student[i].net.state_dict())
    else:
        for i in range(cfg.label_level):
            checkpoint_file_student = os.path.join(model_student[i].model_save_dir_student, f'checkpoint{cfg.al_iter-1}.tar')
            checkpoint_file_teacher = os.path.join(model_student[i].model_save_dir_teacher, f'checkpoint{cfg.al_iter-1}.tar')
            model_student[i].load_checkpoint(checkpoint_file_student, local_rank=0)
            model_teacher[i].load_checkpoint(checkpoint_file_teacher, local_rank=0)
    print('Model loaded, start training')

    # # Segmentation model training
    # for i in range(cfg.label_level):
    #     model_student[i].train_consistencyguide_semi_SGD(train_dataset[i], val_dataset[i], model_teacher[i])
    #     log_out('Iteration ' + str(cfg.al_iter) + ' level '+ str(i) +' training is completed', Log_file)

    # Function to run each model's training in a separate thread
    processes = []
    for i in range(cfg.label_level):
        iteration = cfg.al_iter
        process = mp.Process(target=train_model_process, args=(i, model_student, train_dataset, val_dataset, model_teacher, iteration))
        processes.append(process)
        process.start()

    # Wait for all processes to finish
    for process in processes:
        process.join()

    for i in range(cfg.label_level):
        checkpoint_file_student = os.path.join(model_student[i].model_save_dir_student, f'checkpoint{cfg.al_iter}.tar')
        checkpoint_file_teacher = os.path.join(model_student[i].model_save_dir_teacher, f'checkpoint{cfg.al_iter}.tar')
        model_student[i].load_checkpoint(checkpoint_file_student, local_rank=0)
        model_teacher[i].load_checkpoint(checkpoint_file_teacher, local_rank=0)

    # Active learning
    score_final = generate_score(cfg, model_student, dataset, train_dataset, Log_file, HM.all_valid_h_label)
    log_out('[Main]' + '\t'+ ' scoring finish', Log_file)

    active_chose(cfg, score_final, dataset, log_file=Log_file)
    log_out('[Main]' + '\t'+ ' chosing finish', Log_file)

    del train_dataset
    del val_dataset
    del score_final
    gc.collect()


def test_any_model():
    model = minkNet(cfg, Log_file, dataset)
    val_dataset = Stanford3DDataset(dataset.input_xyz['validation'], dataset.input_colors['validation'],
                                    dataset.input_labels['validation'], dataset.input_names['validation'],
                                    voxel_size=0.05)
    model.load_checkpoint(model_path, local_rank=0)
    model.test_s3dis(val_dataset)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--test_area', type=int, default=5, help='Which area to use for test, option: 1-6 [default: 5]')
    parser.add_argument('--mode', type=str, default='AL_train',
                        help='options: baseline_train, AL_train, test')
    parser.add_argument('--model_path', type=str, default='None', help='pretrained model path')
    FLAGS = parser.parse_args()

    Mode = FLAGS.mode
    test_area = FLAGS.test_area

    mk_dirs()
    Log_file = open(cfg.saving_path + '.txt', 'a')

    label_files = sorted(os.listdir(cfg.label_path))
    label_files = [f for f in label_files if f.endswith('.csv')]
    if len(label_files) == cfg.label_level:
        file_list = [os.path.join(cfg.label_path, f) for f in label_files]
        HM = HierarchicalMatrixReader(files = file_list)
    else:
        raise ValueError('The number of label files does not match the number of label levels')
        
    dataset = []
    for i in range(cfg.label_level):
        valid_h_label = [x[i] for x in HM.all_valid_h_label]
        dataset.append(S3DIS(test_area, cfg, valid_h_label))
        print('label level ', i, ' loaded')

    if Mode == 'AL_train':
        mp.set_start_method('spawn', force=True)
        model_student = []
        model_teacher = []
        for i in range(cfg.label_level):
            model_student.append(minkNet(i, cfg, dataset[i]))
            model_teacher.append(minkNet(i, cfg, dataset[i], isTeacher=True))

        while cfg.al_iter < cfg.max_iter:
            train_HPAL()
            cfg.al_iter += 1
    elif Mode == 'baseline_train':
        train_fullsupervised()
    elif Mode == 'test':
        model_path = FLAGS.model_path
        test_any_model()
    else:
        print('Please enter the right mode')
    print('finish')
