import sys
from config import ConfigS3DIS as cfg
import matplotlib.pyplot as plt
import os

def read_level_log(level_num, learner_path, max_iter):
    with open(learner_path, 'r') as f:
        lines = f.readlines()
        lines = [l for l in lines if l.startswith('[Lev%d]' % level_num)]
    
    student = [[]]
    teacher = [[]]

    for i in range(len(lines)):
        if lines[i].find('ITERATION') != -1 and lines[i].find('ITERATION %d' % int(max_iter-1)) == -1:
            student.append([])
            teacher.append([])

        if lines[i].find('Current') != -1:
            if lines[i].find('teacher') != -1:
                teacher_iou = lines[i][lines[i].find('%') - 7: lines[i].find('%')]
                teacher_iou = float(teacher_iou)
                teacher[-1].append(teacher_iou)
            else:
                student_iou = lines[i][lines[i].find('%') - 7: lines[i].find('%')]
                student_iou = float(student_iou)
                student[-1].append(student_iou)

    return student, teacher

def plot_level_log(log, title):
    iter_len = [len(l) for l in log[0]]
    iter_labels = []
    for j in range(1, len(iter_len)):
        iter_len[j] += iter_len[j-1]
    iter_len = [0] + iter_len
    iter_labels = ['Iteration %d' % i for i in range(len(iter_len)) if i < 5] + ['End']
    
    plt.figure()
    for i in range(len(log)):
        # 拼接每个log[i]中各项
        log[i] = [log[i][j][k] for j in range(len(log[i])) for k in range(len(log[i][j]))]
        line, = plt.plot(range(len(log[i])), log[i], label='level %d' % i)
        
        # 找到每个level的最高点并绘制水平虚线
        max_value = max(log[i])
        max_index = log[i].index(max_value)
        plt.axhline(y=max_value, color=line.get_color(), linestyle='--')
        plt.text(-1, max_value, '%.2f' % max_value, color=line.get_color(), va='bottom', ha='center')
        
    plt.title(title)
    plt.xlabel('Iteration')
    plt.ylabel('IoU')
    plt.xticks(iter_len, iter_labels)  # Set x-axis labels to iteration numbers
    plt.legend()  # Add legend to the plot
    # 保存图片
    plt.savefig(save_path + '/' + title + '.png')
    plt.show()


if __name__ == '__main__':
    level_num = cfg.label_level
    laerner_path = cfg.base_path + '/learner.txt'
    max_iter = cfg.max_iter
    save_path = cfg.base_path + '/result_analysis'

    if not os.path.exists(save_path):
        os.makedirs(save_path)

    student_log = []
    teacher_log = []

    for i in range(level_num):
        cur_lev_student, cur_lev_teacher = read_level_log(i, laerner_path, max_iter)
        student_log.append(cur_lev_student)
        teacher_log.append(cur_lev_teacher)
    
    plot_level_log(student_log, 'student')
    plot_level_log(teacher_log, 'teacher')