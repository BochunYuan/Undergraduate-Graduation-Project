#################################################################
# configuration for training
#################################################################


class ConfigS3DIS:
    # Active learning related
    # For "chosen_rate_AL" and "chosen_points_per_pc", only enable one of them according to the method you use in the "active_chose" function
    chosen_rate_AL = 0.02  # The selection ratio for each iteration in active loop(unit: %)
    # chosen_points_per_pc = 4  # The number of points selected for a single point cloud in each active iteration
    al_iter = 0  # Start iteration
    max_iter = 5  # Maximum number of iterations
    # max_iter = 2  # Maximum number of iterations
    # active_strategy = 'HMMU'  # Scoring strategy for active learning, including random, entropy, MMU, lc, HMMU(ours)
    # Built-in composite-scoring variants for this project:
    #   'HLEU_delete_dot' -> Full Composite = (MI + Rep + Edge) / 3
    #   'HLEU_MI_only'    -> Ablation using only the HLEU-conditioned MI branch
    active_strategy = 'HLEU_MI_only'
    label_level = 3
    
    # Training related
    gpu = '0,1,2' # GPU id, multiple GPUs should be separated by commas
    max_steps = 60000  # inital 60000 Number of training steps
    stat_freq = 40  # inital 40 Frequency of logging
    save_freq = 1000 # inital 1000  Frequency of model saving
    input_channel = 6  # Input channel: xyzrgb
    num_classes = 13  # Number of calsses
    ignore_idx = -100  # Ignore label during training
    train_batch_size_mink = 2 # Original value is 4
    val_batch_size_mink = 8 # Original value is 16
    learning_rate = 1e-1  # Initial learning rate
    ema_keep_rate = 0.955  # Ema keep rate for teacher-student model
    pseudo_threshold = 0.75  # The confidence threshold for filtering the pseudo-labels
    optimizer = 'CosineAnnealingLR'  # Learning rate optimization, 'CosineAnnealingLR' or 'PolyLR' in our experiments
    save_ts_together = False
    propagate_with_uncert = True

    # MC-Dropout settings for MI estimation (T forward passes with dropout active)
    gaui_adv_mc_T         = 10    # number of stochastic forward passes
    gaui_adv_mc_dropout_p = 0.2   # dropout probability injected at inference time

    # Composite scoring runtime:
    #   Full method   : (MI + Rep + Edge) / 3
    #   Ablation path : HLEU-conditioned MI only
    # No per-branch weight configuration is exposed in this project.

    # Rep: number of KMeans clusters for representativeness calculation
    gaui_adv_rep_n_clusters = 10
    # Fit KDE / KMeans on a random subset to bound CPU cost on very large clouds.
    # Set to 0 to disable subsampling.
    gaui_adv_fit_max_points = 50000
    gaui_adv_fit_sample_seed = 0

    # Edge: small constant to avoid division by zero in density-based rarity
    gaui_adv_edge_eps = 1e-6

    # Scoring runtime controls
    score_parallel_jobs = 8
    # HLEU/RUP conditioning still requires all hierarchy levels to build the
    # original global uncertainty reference before composite scoring.
    score_required_levels = (0, 1, 2)
    score_grid_levels = (0.1, 0.5, 1.0)

    # Path related
    # data_path = '/root/autodl-tmp/lcx/prepare/s3dis'  # Processed data path
    data_path = '/root/autodl-tmp/data_prepare/s3dis'
    # data_path = '/root/autodl-tmp/lcx/prepare/s3dis_small'
    label_path = '/root/autodl-tmp/HPAL_Final （2025.5.25存档）/labels'  # processed label path
    # init_labeled_data = '/root/autodl-tmp/lcx/init_labeled/init_labeled20240525.json'  # Path of initial labelled data
    init_labeled_data = '/root/autodl-tmp/data_prepare/init_labeled/init_labeled20240525.json'
    # init_labeled_data = '/root/autodl-tmp/lcx/init_labeled/small20241001.json'
    # Default output root for the upcoming ablation run.
    # Historical full-composite results remain in:
    #   /root/autodl-tmp/Training_results/Run_equal_value
    base_path = '/root/autodl-tmp/Training_results/Ablation_experiment'  # Path to save the training results

    # Paths for various results
    saving_path = base_path + '/learner'  # Log saving path
    model_save_dir_student = base_path + '/mink_pth_s'  # Saving path of student model
    model_save_dir_teacher = base_path + '/mink_pth_t'  # Saving path of teacher model
    labeled_save_path = base_path + '/labeled_data'  # Saving path of the labelled data after each iteration
    save_path_feat = base_path + '/feat'  # Feature saving path
    save_path_probs = base_path + '/probs'  # Prediction saving path

class ConfigAttentionModel:
    patience = 800  # 早停参数
    lr = 5e-5  # 学习率
    batch_size = 12  # 批量大小
    epochs = 800  # 训练轮数
    device = 'cuda'  # 设备类型
    seed = 42  # 随机种子
    log_dir = 'logs'  # 日志保存路径
    gpu = '0'
    train_val_split = 0.1
    hidden_dim = 128
    dropout = 0.5
    num_classes = 13

    # 目前最高配置
    # patience = 600  # 早停参数
    # lr = 5e-4  # 学习率
    # batch_size = 12  # 批量大小
    # epochs = 600  # 训练轮数
    # device = 'cuda'  # 设备类型
    # seed = 42  # 随机种子
    # log_dir = 'logs'  # 日志保存路径
    # gpu = '0'
    # train_val_split = 0.1
    # hidden_dim = 128
    # dropout = 0.5
    # num_classes = 13

    data_path = ConfigS3DIS.data_path
    label_path = ConfigS3DIS.label_path
    init_labeled_data = ConfigS3DIS.init_labeled_data
    base_path = ConfigS3DIS.base_path
    labeled_save_path = ConfigS3DIS.labeled_save_path
    model_save_path = ConfigS3DIS.base_path + '/attention_model_5403/model.pth'
    log_dir = ConfigS3DIS.base_path + '/attention_model/logs'
    
    level_dims = [3, 6, 13]
