import glob
import json
import os
from os.path import join

import numpy as np


class S3DIS:
    def __init__(self, test_area_idx, cfg, valid_h_label, al_iter=0):
        self.name = 'S3DIS'
        self.path = cfg.data_path
        self.all_valid_h_label = valid_h_label
        self.num_classes = len(set(valid_h_label))
        self.label_values = np.sort(list(set(valid_h_label)))
        # self.label_to_idx = 

        self.val_split = 'Area_' + str(test_area_idx) # 'Area_1/2/3/4/5/6'
        self.all_files = [] 
        print('all valid h label:')
        print(self.all_valid_h_label)
        for area in ['Area_1', 'Area_2', 'Area_3', 'Area_4', 'Area_5', 'Area_6']:
            cur_dir = os.path.join(self.path, area, 'coords') # 'data/S3DIS/Area_1/coords'
            files = glob.glob(join(cur_dir, '*.npy')) # ['data/S3DIS/Area_1/coords/1.npy', 'data/S3DIS/Area_1/coords/2.npy', ...]
            self.all_files += files 

        # print(self.all_files)
        if al_iter == 0:
            f_l = open(cfg.init_labeled_data, 'r')
            self.labeled_points = json.load(f_l)
            f_l.close()
        else:
            f_l = open(cfg.labeled_save_path + f'/labeled_data_{al_iter - 1}.json', 'r')
            self.labeled_points = json.load(f_l)
            f_l.close()

        self.input_xyz = {'train': [], 'validation': []}
        self.input_colors = {'train': [], 'validation': []}
        self.input_labels = {'train': [], 'validation': []}
        self.input_names = {'train': [], 'validation': []}

        self.load_sub_sampled_clouds()

    def load_sub_sampled_clouds(self):
        for i, file_path in enumerate(self.all_files):
            xyz_path = file_path
            colors_path = file_path.replace('coords', 'rgb')
            label_path = file_path.replace('coords', 'labels')

            area = file_path.split('/')[-3] # 'Area_1/2/3/4/5/6'
            cloud_name = file_path.split('/')[-1][:-4] # 'Hallway_1', 'Office_1', ...
            sp_key_name = area + '#' + cloud_name

            if sp_key_name in self.labeled_points:
                cloud_split = 'train'
                print('train:' + sp_key_name)
            else:
                cloud_split = 'validation'
                print('val:' + sp_key_name)

            self.input_xyz[cloud_split] += [xyz_path]
            self.input_colors[cloud_split] += [colors_path]
            self.input_names[cloud_split] += [sp_key_name]
            input_labels_ = np.load(label_path)
            if self.num_classes != 13:
                self.input_labels[cloud_split] += [np.array([[self.all_valid_h_label[l[0]]] for l in input_labels_])]
            else:
                self.input_labels[cloud_split] += [input_labels_]