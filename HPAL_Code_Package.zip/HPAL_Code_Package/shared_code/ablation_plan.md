# Ablation Output Plan

## Recommended layout

### Table 1: Main ablation table

Use one row per hierarchy level and one method group. The suggested columns are:

`Method | active_strategy | Level | Student Best mIoU (%) | Teacher Best mIoU (%) | Delta vs Full (Student) | Delta vs Full (Teacher)`

Recommended row order:

1. `Full Composite / HLEU_delete_dot / Level 0`
2. `Full Composite / HLEU_delete_dot / Level 1`
3. `Full Composite / HLEU_delete_dot / Level 2`
4. `HLEU_MI_only / HLEU_MI_only / Level 0`
5. `HLEU_MI_only / HLEU_MI_only / Level 1`
6. `HLEU_MI_only / HLEU_MI_only / Level 2`

Interpretation rule:

- `Delta vs Full = Ablation - Full Composite`
- Negative values mean the removed branches (`Rep + Edge`) were helping.
- If one level drops much more than the others, that is the strongest evidence for that branch combination being important at that hierarchy level.

Template file:

- [ablation_table_template.csv](/root/autodl-tmp/HPAL_Final%20（2025.5.25存档）/experiments/ablation_table_template.csv)

## Curves

### Figure 1: Student best-mIoU curve

- Horizontal axis: `AL Iteration`
- Vertical axis: `Best val mIoU (%)`
- 3 subplots in one row: `Level 0`, `Level 1`, `Level 2`
- Blue line: `Full Composite`
- Red line: `HLEU_MI_only`

### Figure 2: Teacher best-mIoU curve

- Same layout as Figure 1
- Same color convention

Recommended caption style:

- `Comparison of Full Composite and HLEU_MI_only across AL iterations on the three hierarchy levels.`

## Export workflow

### Step 1: Export CSV from each run

For the historical full-composite run:

```bash
python /root/autodl-tmp/HPAL_Final\ （2025.5.25存档）/tools/export_ablation_results.py \
  --run_dir /root/autodl-tmp/Training_results/Run_equal_value \
  --experiment_name Full_Composite \
  --strategy_name HLEU_delete_dot
```

For the new ablation run:

```bash
python /root/autodl-tmp/HPAL_Final\ （2025.5.25存档）/tools/export_ablation_results.py \
  --run_dir /root/autodl-tmp/Training_results/Ablation_experiment \
  --experiment_name HLEU_MI_only \
  --strategy_name HLEU_MI_only
```

### Step 2: Generate comparison curves

```bash
python /root/autodl-tmp/HPAL_Final\ （2025.5.25存档）/tools/plot_ablation_curves.py \
  --baseline_csv /root/autodl-tmp/Training_results/Run_equal_value/result_analysis/iteration_metrics.csv \
  --ablation_csv /root/autodl-tmp/Training_results/Ablation_experiment/result_analysis/iteration_metrics.csv \
  --output_dir /root/autodl-tmp/Training_results/Ablation_experiment/result_analysis/figures
```

## Output files

After export, the new run will contain:

- `result_analysis/iteration_metrics.csv`
- `result_analysis/best_metrics.csv`
- `result_analysis/ablation_summary.csv`
- `result_analysis/figures/ablation_student_curves.png`
- `result_analysis/figures/ablation_teacher_curves.png`
