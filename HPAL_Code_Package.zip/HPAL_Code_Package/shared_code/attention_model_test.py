import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import gc
from torch.utils.data import Dataset, DataLoader

from config import ConfigAttentionModel
from config import ConfigS3DIS as cfg
from data_base_HLEU import S3DIS
from Mink.dataloader.dataset import Stanford3DDataset
from label_reader import generate_paths
from Mink.base_agent_HLEU import BaseTrainer as minkNet
from attention_model_trainer import AttentionModel, HierarchicalProbDataset

# 设置随机种子，确保结果可复现
torch.manual_seed(42)
np.random.seed(42)

# 初始化配置
att_cfg = ConfigAttentionModel()
torch.manual_seed(att_cfg.seed)
np.random.seed(att_cfg.seed)

def collect_val_probs():
    """收集验证集的概率预测结果"""
    # 设置GPU
    current_gpu_setting = os.environ.get('CUDA_VISIBLE_DEVICES', '')
    os.environ['CUDA_VISIBLE_DEVICES'] = cfg.gpu
    print(f"Loading probability data using GPU: {cfg.gpu}")
    
    # 加载标签树
    label_files = os.listdir(cfg.label_path)
    label_files = [f for f in label_files if f.split('.')[0][-1].isdigit()]
    if len(label_files) == cfg.label_level:
        file_list = [os.path.join(cfg.label_path, f) for f in label_files]
        valid_h_label = generate_paths(file_list)
    else:
        # 恢复原始GPU设置
        os.environ['CUDA_VISIBLE_DEVICES'] = current_gpu_setting
        raise ValueError('The number of label files does not match the number of label levels')
    
    # 加载数据集
    dataset = []
    valid_h_label_transposed = []
    for i in range(cfg.label_level):
        valid_h_label_ = [x[i] for x in valid_h_label]
        valid_h_label_transposed.append(valid_h_label_)
        dataset.append(S3DIS(5, cfg, valid_h_label_, 5))
        print('label level ', i, ' loaded')
    
    # 加载模型
    model = []
    val_dataset = []
    model_path = cfg.model_save_dir_student
    for i in range(cfg.label_level):
        model.append(minkNet(level=i, args=cfg, dataset=dataset[i], isTeacher=False))
        val_dataset.append(Stanford3DDataset(dataset[i].input_xyz['validation'], 
                                   dataset[i].input_colors['validation'],
                                   dataset[i].input_labels['validation'], 
                                   dataset[i].input_names['validation'],
                                   voxel_size=0.05))
        checkpoint_file = os.path.join(model_path, f'level_{i}', f'checkpoint{cfg.max_iter-1}.tar')
        model[i].load_checkpoint(checkpoint_file, 0)
    print('model loaded')
    
    # 获取验证集的概率预测结果
    probs = [model[i].get_predict_prob(val_dataset[i]) for i in range(cfg.label_level)]
    print('probability collected')
    
    # 恢复原始GPU设置
    os.environ['CUDA_VISIBLE_DEVICES'] = current_gpu_setting
    print(f"Restored to attention model GPU setting: {att_cfg.gpu}")
    
    return probs, val_dataset, model[-1], valid_h_label_transposed

def prepare_attention_input(probs, val_dataset):
    """准备注意力模型的输入数据"""
    attention_input_probs = []
    labels = []
    
    dataset_len = val_dataset[0].__len__()
    for cloud_id in range(dataset_len):
        cloud_probs = []
        for point_idx in range(len(probs[-1][cloud_id])):
            point_probs = []
            for level in range(cfg.label_level):
                point_probs.append(probs[level][cloud_id][point_idx])
            cloud_probs.append(point_probs)
        
        attention_input_probs.extend(cloud_probs)
        labels.extend(val_dataset[-1].labels[cloud_id])
    
    return attention_input_probs, np.array(labels)

def load_attention_model(device):
    """加载训练好的注意力模型"""
    model = AttentionModel(
        level_dims=att_cfg.level_dims,
        hidden_dim=att_cfg.hidden_dim,
        num_classes=att_cfg.num_classes,
        dropout=att_cfg.dropout
    ).to(device)
    
    # 加载模型参数
    checkpoint = torch.load(att_cfg.model_save_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    print(f"Loaded attention model from {att_cfg.model_save_path}")
    print(f"Model validation accuracy: {checkpoint['val_acc']:.4f}")
    
    return model

def predict_with_attention(model, probs, device, batch_size=128):
    """使用注意力模型进行预测"""
    model.eval()
    
    all_predictions = []
    
    # 按点云分批进行预测
    for cloud_id in range(len(probs[0])):
        cloud_probs = []
        for point_idx in range(len(probs[-1][cloud_id])):
            point_probs = []
            for level in range(cfg.label_level):
                point_probs.append(probs[level][cloud_id][point_idx])
            cloud_probs.append(point_probs)
        
        cloud_dataset = HierarchicalProbDataset(cloud_probs, np.zeros(len(cloud_probs)))
        cloud_loader = DataLoader(cloud_dataset, batch_size=batch_size)
        
        cloud_predictions = []
        with torch.no_grad():
            for batch_probs, _ in cloud_loader:
                batch_probs = [probs.to(device) for probs in batch_probs]
                logits, _ = model(batch_probs)
                _, predicted = torch.max(logits, 1)
                cloud_predictions.extend(predicted.cpu().numpy())
        
        all_predictions.append(np.array(cloud_predictions))
    
    return all_predictions

def main():
    # 设置注意力模型使用的GPU
    print(f"Attention model will use GPU: {att_cfg.gpu}")
    os.environ['CUDA_VISIBLE_DEVICES'] = att_cfg.gpu
    
    # 检测GPU是否可用
    if not torch.cuda.is_available():
        print("Error: No available GPU detected. This program requires a GPU to run.")
        print(f"Set GPU ID: {att_cfg.gpu}")
        print(f"CUDA available: {torch.cuda.is_available()}")
        return
    
    device = torch.device('cuda')
    print(f'Using device: {device}')
    if torch.cuda.is_available():
        print(f'GPU model: {torch.cuda.get_device_name(0)}')
    
    # 收集验证集的概率预测结果
    probs, val_dataset, eval_model, valid_h_label = collect_val_probs()
    
    # 加载注意力模型
    attention_model = load_attention_model(device)
    
    # 使用注意力模型进行预测
    print("Predicting with attention model...")
    final_prediction = predict_with_attention(attention_model, probs, device)
    
    # 计算mIoU
    print("Calculating mIoU...")
    eval_model.cal_miou_HLEU(final_prediction, val_dataset[-1])
    
    print("\nDirectly use the last level prediction:")
    final_prediction_last_level = get_final_prediction_last_level(val_dataset, probs, valid_h_label)
    eval_model.cal_miou_HLEU(final_prediction_last_level, val_dataset[-1])
    
    print("\nComparing with simple addition fusion:")
    final_prediction_addition = get_final_prediction_addition(val_dataset, probs, valid_h_label)
    print('add all levels')
    eval_model.cal_miou_HLEU(final_prediction_addition, val_dataset[-1])
    
    # 释放内存
    del val_dataset
    del eval_model
    del probs
    del attention_model
    gc.collect()

def get_final_prediction_addition(val_dataset, prob, valid_h_label):
    """简单加法融合（从s3dis_test_HLEU.py复制）"""
    dataset_len = val_dataset[0].__len__()
    final_prediction = []
    
    for cloud_id in range(dataset_len):
        # 先获取每个点云的最后一层的概率
        cur_cloud_final_prob = prob[-1][cloud_id]

        # 把每个路径的所有概率相加
        for level in range(cfg.label_level-1):
            cur_cloud_cur_level_prob = prob[level][cloud_id]
            transferred_prob = cur_cloud_cur_level_prob[np.arange(cur_cloud_cur_level_prob.shape[0])[:, None], valid_h_label[level]]
            cur_cloud_final_prob += transferred_prob

        # 选择最大概率的路径作为最终预测
        cur_cloud_final_pred = cur_cloud_final_prob.argmax(1)
        final_prediction.append(cur_cloud_final_pred)
    
    return final_prediction

def get_final_prediction_last_level(val_dataset, prob, valid_h_label):
    """直接使用最后一层的预测"""
    dataset_len = val_dataset[0].__len__()
    final_prediction = []
    
    for cloud_id in range(dataset_len):
        cur_cloud_final_prob = prob[-1][cloud_id]
        cur_cloud_final_pred = cur_cloud_final_prob.argmax(1)
        final_prediction.append(cur_cloud_final_pred)
    
    return final_prediction

if __name__ == '__main__':
    main() 