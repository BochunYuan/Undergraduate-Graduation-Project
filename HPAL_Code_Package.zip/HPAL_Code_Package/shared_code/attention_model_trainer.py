import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, random_split
import matplotlib.pyplot as plt
from config import ConfigAttentionModel
from config import ConfigS3DIS as train_cfg
from data_base_HLEU import S3DIS
from Mink.dataloader.dataset import Stanford3DDataset
from label_reader import generate_paths
from Mink.base_agent_HLEU import BaseTrainer as minkNet
import sys
import json

# 设置随机种子，确保结果可复现
torch.manual_seed(42)
np.random.seed(42)

# 初始化配置
cfg = ConfigAttentionModel()
torch.manual_seed(cfg.seed)
np.random.seed(cfg.seed)

# 确保模型保存路径存在
os.makedirs(os.path.dirname(cfg.model_save_path), exist_ok=True)
os.makedirs(cfg.log_dir, exist_ok=True)

# 数据集类
class HierarchicalProbDataset(Dataset):
    def __init__(self, probs, labels):
        """
        probs: 列表，包含每个点的三层概率 [num_points, 3, level_dims]
        labels: 数组，每个点在最细粒度层次上的标签 [num_points]
        """
        self.probs = probs
        self.labels = labels
    
    def __len__(self):
        return len(self.labels)
    
    def __getitem__(self, idx):
        probs_tensor = [torch.tensor(self.probs[idx][i], dtype=torch.float32) for i in range(3)]
        label = torch.tensor(self.labels[idx], dtype=torch.long)
        return probs_tensor, label

# 注意力模型
class AttentionModel(nn.Module):
    def __init__(self, level_dims, hidden_dim, num_classes, dropout=0.2):
        super(AttentionModel, self).__init__()
        
        self.level_dims = level_dims
        
        # 对每一层的概率编码
        self.encoders = nn.ModuleList([
            nn.Sequential(
                nn.Linear(dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout)
            ) for dim in level_dims
        ])
        
        # 注意力机制
        self.attention = nn.Sequential(
            nn.Linear(hidden_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )
        
        # 融合层
        self.fusion = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # 分类头
        self.classifier = nn.Linear(hidden_dim, num_classes)
    
    def forward(self, probs_list):
        # 编码每层概率
        encoded_features = []
        for i, probs in enumerate(probs_list):
            encoded = self.encoders[i](probs)
            encoded_features.append(encoded)
        
        # 计算注意力权重
        encoded_stack = torch.stack(encoded_features, dim=1)  # [batch, 3, hidden_dim]
        attention_weights = self.attention(encoded_stack)  # [batch, 3, 1]
        attention_weights = F.softmax(attention_weights, dim=1)  # [batch, 3, 1]
        
        # 加权融合特征
        weighted_features = encoded_stack * attention_weights  # [batch, 3, hidden_dim]
        fused_features = torch.sum(weighted_features, dim=1)  # [batch, hidden_dim]
        
        # 进一步特征处理
        fused_features = self.fusion(fused_features)
        
        # 分类
        logits = self.classifier(fused_features)
        
        return logits, attention_weights

    

def collect_labeled_labels(labeled_index):
    labels = []
    areas = os.listdir(train_cfg.data_path)
    for area in areas:
        if area == 'Area_5':
            continue
        area_path = os.path.join(train_cfg.data_path, area, 'labels')
        label_files = os.listdir(area_path)
        for label_file in label_files:
            label_path = os.path.join(area_path, label_file)
            label_data = np.load(label_path)
            labels.append(label_data.reshape(-1))
    labeled_labels = []
    
    
    for i in range(len(labeled_index)):
        labeled_labels.append(labels[i][labeled_index[i]])
    
    del labels
    
    return np.concatenate(labeled_labels)

# 加载实际数据函数
def load_real_data():
    """
    从HPAL系统中加载实际数据
    
    返回:
        probs: 列表，包含每个点的三层概率 [num_points, 3, level_dims]
        labels: 数组，每个点在最细粒度层次上的标签 [num_points]
    """
    # 设置为训练三层网络的GPU配置
    current_gpu_setting = os.environ.get('CUDA_VISIBLE_DEVICES', '')
    os.environ['CUDA_VISIBLE_DEVICES'] = train_cfg.gpu
    print(f"Loading probability data using GPU: {train_cfg.gpu}")
    
    label_files = os.listdir(train_cfg.label_path)
    label_files = [f for f in label_files if f.split('.')[0][-1].isdigit()]
    if len(label_files) == train_cfg.label_level:
        file_list = [os.path.join(train_cfg.label_path, f) for f in label_files]
        valid_h_label = generate_paths(file_list)
    else:
        # 恢复原始GPU设置
        os.environ['CUDA_VISIBLE_DEVICES'] = current_gpu_setting
        raise ValueError('The number of label files does not match the number of label levels')
    
    dataset = []
    valid_h_label_transposed = []
    for i in range(train_cfg.label_level):
        valid_h_label_ = [x[i] for x in valid_h_label]
        valid_h_label_transposed.append(valid_h_label_)
        dataset.append(S3DIS(5, train_cfg, valid_h_label_, 5))
        print('label level ', i, ' loaded')
        
    model = []
    train_dataset = []
    model_path = train_cfg.model_save_dir_student
    for i in range(train_cfg.label_level):
        model.append(minkNet(level=i, args=train_cfg, dataset=dataset[i], isTeacher=False))
        train_dataset.append(Stanford3DDataset(dataset[i].input_xyz['train'], dataset[i].input_colors['train'],
                                    dataset[i].input_labels['train'], dataset[i].input_names['train'],labeled_points=dataset[i].labeled_points,
                                    voxel_size=0.05))
        checkpoint_file = os.path.join(model_path, f'level_{i}', f'checkpoint{train_cfg.max_iter-1}.tar')
        model[i].load_checkpoint(checkpoint_file, 0) 
    print('model loaded')

    # 获取三个模型的预测概率
    # probs是三层的list，每一层表示一个label level，每一层也各是list，其中每一项表示一个点云的概率数组
    init_probs = [model[i].get_predict_prob(train_dataset[i]) for i in range(train_cfg.label_level)]
    # 恢复原始GPU设置
    os.environ['CUDA_VISIBLE_DEVICES'] = current_gpu_setting
    
    init_labels = train_dataset[-1].labels
    
    probs = []
    labels = []
    
    file_names = train_dataset[-1].file_names
    
    for key, value in train_dataset[-1].labeled_points.items():
        value_array = np.array(value)
        labeled_index = np.where(value_array == True)[0]
        
        pc_id = file_names.index(key)
        
        if pc_id == -1:
            raise ValueError('pc_id not found')
        
        
        for idx in labeled_index:
            probs.append([init_probs[level][pc_id][idx] for level in range(train_cfg.label_level)])
        
        labels.append(init_labels[pc_id][labeled_index])
        
    labels = np.concatenate(labels).reshape(-1)
        
    print("probability collected")
    
    
    return probs, labels


# 训练函数
def train(model, train_loader, val_loader, criterion, optimizer, device, epochs, patience):
    best_val_acc = 0
    patience_counter = 0
    train_losses = []
    val_accs = []
    
    for epoch in range(epochs):
        model.train()
        epoch_loss = 0
        
        for batch_probs, batch_labels in train_loader:
            # 将数据移至设备
            batch_probs = [probs.to(device) for probs in batch_probs]
            batch_labels = batch_labels.to(device)
            
            # 前向传播
            logits, _ = model(batch_probs)
            loss = criterion(logits, batch_labels)
            
            # 反向传播和优化
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            epoch_loss += loss.item()
        
        # 计算平均训练损失
        avg_loss = epoch_loss / len(train_loader)
        train_losses.append(avg_loss)
        
        # 在验证集上评估
        val_acc = evaluate(model, val_loader, device)
        val_accs.append(val_acc)
        
        if epoch % 100 == 0:
            print(f'Epoch {epoch}/{epochs}, Training loss: {avg_loss:.4f}, Validation accuracy: {val_acc:.4f}')
        
        # 早停检查
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            patience_counter = 0
            # 保存最佳模型
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_acc': val_acc,
            }, cfg.model_save_path)
            print(f'Model saved to {cfg.model_save_path}')
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f'No improvement for {patience} epochs, early stopping')
                break
    
    return train_losses, val_accs, best_val_acc

# 评估函数
def evaluate(model, data_loader, device):
    model.eval()
    correct = 0
    total = 0
    
    with torch.no_grad():
        for batch_probs, batch_labels in data_loader:
            batch_probs = [probs.to(device) for probs in batch_probs]
            batch_labels = batch_labels.to(device)
            
            logits, _ = model(batch_probs)
            _, predicted = torch.max(logits, 1)
            
            total += batch_labels.size(0)
            correct += (predicted == batch_labels).sum().item()
    
    return correct / total

# 绘制训练过程图表
def plot_training_process(train_losses, val_accs):
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.plot(train_losses)
    plt.title('training loss')
    plt.xlabel('epoch')
    plt.ylabel('loss')
    
    plt.subplot(1, 2, 2)
    plt.plot(val_accs)
    plt.title('validation accuracy')
    plt.xlabel('epoch')
    plt.ylabel('accuracy')
    
    plt.tight_layout()
    plt.savefig(os.path.join(cfg.log_dir, 'training_process.png'))
    plt.close()

# 主函数
def main():
    # 设置注意力模型训练使用的GPU
    print(f"注意力模型将使用GPU: {cfg.gpu}")
    os.environ['CUDA_VISIBLE_DEVICES'] = cfg.gpu
    
    # 检测GPU是否可用，如果不可用则报错退出
    if not torch.cuda.is_available():
        print("Error: No available GPU detected. This program requires a GPU to run.")
        print(f"Set GPU ID: {cfg.gpu}")
        print(f"CUDA available: {torch.cuda.is_available()}")
        print(f"Number of available GPUs: {torch.cuda.device_count() if torch.cuda.is_available() else 0}")
        sys.exit(1)
        
    device = torch.device('cuda')
    print(f'Using device: {device}')
    if torch.cuda.is_available():
        print(f'GPU model: {torch.cuda.get_device_name(0)}')
        print(f'GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1024 / 1024 / 1024:.2f} GB')
    
    # 数据来源选择
    USE_REAL_DATA = True  # 设置为True时使用实际数据，False时使用模拟数据
    
    # 加载数据
    print('Loading data...')
    probs, labels = load_real_data()
    
    # 创建数据集
    dataset = HierarchicalProbDataset(probs, labels)
    
    # 划分训练集和验证集
    val_size = int(len(dataset) * cfg.train_val_split)
    train_size = len(dataset) - val_size
    train_dataset, val_dataset = random_split(dataset, [train_size, val_size])
    
    # 创建数据加载器
    train_loader = DataLoader(train_dataset, batch_size=cfg.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=cfg.batch_size)
    
    print(f'Training set size: {train_size}, Validation set size: {val_size}')
    
    # 初始化模型
    model = AttentionModel(
        level_dims=cfg.level_dims,
        hidden_dim=cfg.hidden_dim,
        num_classes=cfg.num_classes,
        dropout=cfg.dropout
    ).to(device)
    
    # 定义损失函数和优化器
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    
    # 训练模型
    print('Start training...')
    train_losses, val_accs, best_val_acc = train(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        criterion=criterion,
        optimizer=optimizer,
        device=device,
        epochs=cfg.epochs,
        patience=cfg.patience
    )
    
    # 绘制训练过程
    plot_training_process(train_losses, val_accs)
    
    print(f'Training completed! Best validation accuracy: {best_val_acc:.4f}')

if __name__ == '__main__':
    main() 