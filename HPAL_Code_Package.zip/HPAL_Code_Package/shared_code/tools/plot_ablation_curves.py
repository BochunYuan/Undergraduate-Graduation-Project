import argparse
import csv
import math
import os
from collections import defaultdict

import matplotlib.pyplot as plt


def load_iteration_metrics(csv_path):
    rows = []
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(
                {
                    'iteration': int(row['iteration']),
                    'level': int(row['level']),
                    'role': row['role'],
                    'current_miou': float(row['current_miou']),
                    'best_miou': float(row['best_miou']),
                }
            )
    return rows


def group_latest_best_by_iteration(rows, role):
    grouped = defaultdict(dict)
    for row in rows:
        if row['role'] != role:
            continue
        grouped[row['level']][row['iteration']] = row['best_miou']

    output = {}
    for level, iter_map in grouped.items():
        points = sorted(iter_map.items())
        output[level] = points
    return output


def plot_comparison(baseline_csv, ablation_csv, output_path, role='student'):
    baseline_rows = load_iteration_metrics(baseline_csv)
    ablation_rows = load_iteration_metrics(ablation_csv)

    baseline = group_latest_best_by_iteration(baseline_rows, role)
    ablation = group_latest_best_by_iteration(ablation_rows, role)

    levels = sorted(set(baseline.keys()) | set(ablation.keys()))
    if not levels:
        raise ValueError('No level data found for plotting.')

    fig, axes = plt.subplots(1, len(levels), figsize=(5.2 * len(levels), 4.6), squeeze=False)
    colors = {
        'Full Composite': '#1f4e79',
        'HLEU_MI_only': '#c44e52',
    }

    for idx, level in enumerate(levels):
        ax = axes[0][idx]
        base_points = baseline.get(level, [])
        abl_points = ablation.get(level, [])

        if base_points:
            x, y = zip(*base_points)
            ax.plot(x, y, marker='o', linewidth=2.2, color=colors['Full Composite'], label='Full Composite')
        if abl_points:
            x, y = zip(*abl_points)
            ax.plot(x, y, marker='s', linewidth=2.2, color=colors['HLEU_MI_only'], label='HLEU_MI_only')

        ax.set_title(f'Level {level} ({role})')
        ax.set_xlabel('AL Iteration')
        ax.set_ylabel('Best val mIoU (%)')
        ax.grid(True, linestyle='--', linewidth=0.7, alpha=0.5)
        ax.set_axisbelow(True)

        all_y = [point[1] for point in base_points + abl_points]
        if all_y:
            ymin = math.floor(min(all_y) - 1)
            ymax = math.ceil(max(all_y) + 1)
            if ymin < ymax:
                ax.set_ylim(ymin, ymax)

    handles, labels = axes[0][0].get_legend_handles_labels()
    if handles:
        fig.legend(handles, labels, loc='upper center', ncol=2, frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.92))

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fig.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description='Plot Full Composite vs HLEU_MI_only comparison curves.')
    parser.add_argument('--baseline_csv', required=True, help='iteration_metrics.csv for Full Composite')
    parser.add_argument('--ablation_csv', required=True, help='iteration_metrics.csv for HLEU_MI_only')
    parser.add_argument('--output_dir', required=True, help='Directory to save output figures')
    args = parser.parse_args()

    output_dir = os.path.abspath(args.output_dir)
    os.makedirs(output_dir, exist_ok=True)

    plot_comparison(
        args.baseline_csv,
        args.ablation_csv,
        os.path.join(output_dir, 'ablation_student_curves.png'),
        role='student',
    )
    plot_comparison(
        args.baseline_csv,
        args.ablation_csv,
        os.path.join(output_dir, 'ablation_teacher_curves.png'),
        role='teacher',
    )

    print(f'Exported: {os.path.join(output_dir, "ablation_student_curves.png")}')
    print(f'Exported: {os.path.join(output_dir, "ablation_teacher_curves.png")}')


if __name__ == '__main__':
    main()
