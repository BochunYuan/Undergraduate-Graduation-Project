import argparse
import csv
import os
import re
from typing import Dict, List, Optional


LINE_RE = re.compile(
    r'^\[Lev(?P<level>\d+)\]\s+'
    r'(?P<role>teacher\s+)?Current val miou is\s+'
    r'(?P<current>[0-9]+(?:\.[0-9]+)?)\s*%,\s*while the best val miou is\s+'
    r'(?P<best>[0-9]+(?:\.[0-9]+)?)\s*%'
)

ITER_RE = re.compile(r'ITERATION\s+(?P<iteration>\d+)\s+TRAINING FINISHED')


def parse_log(log_path: str) -> Dict[str, List[dict]]:
    current_iteration = 0
    pending_iter_records: Dict[tuple, List[dict]] = {}
    final_records: List[dict] = []
    best_by_level_role: Dict[tuple, float] = {}

    with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
        for raw_line in f:
            line = raw_line.strip()

            metric_match = LINE_RE.search(line)
            if metric_match:
                level = int(metric_match.group('level'))
                role = 'teacher' if metric_match.group('role') else 'student'
                current_miou = float(metric_match.group('current'))
                best_miou = float(metric_match.group('best'))
                key = (level, role)

                best_by_level_role[key] = max(best_by_level_role.get(key, float('-inf')), best_miou)
                pending_iter_records.setdefault(key, []).append(
                    {
                        'iteration': current_iteration,
                        'level': level,
                        'role': role,
                        'current_miou': current_miou,
                        'best_miou': best_miou,
                    }
                )
                continue

            iter_match = ITER_RE.search(line)
            if not iter_match:
                continue

            finished_iteration = int(iter_match.group('iteration'))
            level_prefix = re.search(r'^\[Lev(?P<level>\d+)\]', line)
            if level_prefix is None:
                continue
            level = int(level_prefix.group('level'))

            for role in ('student', 'teacher'):
                key = (level, role)
                records = pending_iter_records.get(key, [])
                if not records:
                    continue

                record = records[-1].copy()
                record['iteration'] = finished_iteration
                final_records.append(record)
                pending_iter_records[key] = []

            current_iteration = max(current_iteration, finished_iteration + 1)

    # Fallback for incomplete runs: keep the latest seen chunk even if the
    # iteration-finished marker has not been written yet.
    for records in pending_iter_records.values():
        if records:
            final_records.append(records[-1])

    final_records.sort(key=lambda x: (x['iteration'], x['level'], x['role']))

    best_summary = []
    for (level, role), best_miou in sorted(best_by_level_role.items()):
        best_summary.append(
            {
                'level': level,
                'role': role,
                'best_miou': best_miou,
            }
        )

    return {
        'per_iteration': final_records,
        'best_summary': best_summary,
    }


def write_csv(path: str, rows: List[dict], fieldnames: List[str]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def build_experiment_summary(
    experiment_name: str,
    strategy_name: str,
    results: Dict[str, List[dict]],
) -> List[dict]:
    best_lookup = {(row['level'], row['role']): row['best_miou'] for row in results['best_summary']}
    rows = []
    for level in sorted({row['level'] for row in results['best_summary']}):
        student_best = best_lookup.get((level, 'student'))
        teacher_best = best_lookup.get((level, 'teacher'))
        rows.append(
            {
                'experiment_name': experiment_name,
                'strategy_name': strategy_name,
                'level': level,
                'student_best_miou': '' if student_best is None else f'{student_best:.3f}',
                'teacher_best_miou': '' if teacher_best is None else f'{teacher_best:.3f}',
            }
        )
    return rows


def infer_strategy_name(run_dir: str, explicit_strategy: Optional[str]) -> str:
    if explicit_strategy:
        return explicit_strategy

    base_name = os.path.basename(os.path.normpath(run_dir))
    if 'ablation' in base_name.lower():
        return 'HLEU_MI_only'
    return 'HLEU_delete_dot'


def main() -> None:
    parser = argparse.ArgumentParser(description='Export ablation-ready CSV summaries from learner.txt')
    parser.add_argument('--run_dir', required=True, help='Training result directory containing learner.txt')
    parser.add_argument('--experiment_name', default=None, help='Display name used in summary CSV')
    parser.add_argument('--strategy_name', default=None, help='Strategy tag written into summary CSV')
    args = parser.parse_args()

    run_dir = os.path.abspath(args.run_dir)
    learner_path = os.path.join(run_dir, 'learner.txt')
    if not os.path.exists(learner_path):
        raise FileNotFoundError(f'learner.txt not found: {learner_path}')

    analysis_dir = os.path.join(run_dir, 'result_analysis')
    os.makedirs(analysis_dir, exist_ok=True)

    parsed = parse_log(learner_path)

    per_iteration_path = os.path.join(analysis_dir, 'iteration_metrics.csv')
    best_summary_path = os.path.join(analysis_dir, 'best_metrics.csv')
    experiment_summary_path = os.path.join(analysis_dir, 'ablation_summary.csv')

    write_csv(
        per_iteration_path,
        parsed['per_iteration'],
        ['iteration', 'level', 'role', 'current_miou', 'best_miou'],
    )
    write_csv(
        best_summary_path,
        parsed['best_summary'],
        ['level', 'role', 'best_miou'],
    )

    experiment_name = args.experiment_name or os.path.basename(run_dir)
    strategy_name = infer_strategy_name(run_dir, args.strategy_name)
    summary_rows = build_experiment_summary(experiment_name, strategy_name, parsed)
    write_csv(
        experiment_summary_path,
        summary_rows,
        ['experiment_name', 'strategy_name', 'level', 'student_best_miou', 'teacher_best_miou'],
    )

    print(f'Exported: {per_iteration_path}')
    print(f'Exported: {best_summary_path}')
    print(f'Exported: {experiment_summary_path}')


if __name__ == '__main__':
    main()
