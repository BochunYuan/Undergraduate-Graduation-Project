import numpy as np
import os
import glob
import json

root = '/root/autodl-tmp/lcx/prepare/s3dis'
small_dataset_save_path = '/root/autodl-tmp/lcx/prepare/s3dis_small3'
init_labelled_save_path = '/root/autodl-tmp/lcx/init_labeled/small20241003.json'

def mkdir(path):
    if not os.path.exists(path):
        os.makedirs(path)

def generate_small_dataset(root, dest, ptc_num_each_area):
    file_count = 0
    mkdir(dest)
    areas = os.listdir(root)
    for area in areas:
        area_path = os.path.join(root, area)
        small_area_path = os.path.join(dest, area)
        mkdir(small_area_path)

        feats = os.listdir(area_path)

        for feat in feats:
            feat_path = os.path.join(area_path, feat)
            small_feat_path = os.path.join(small_area_path, feat)
            mkdir(small_feat_path)

            files = os.listdir(feat_path)
            if len(files) > ptc_num_each_area and ptc_num_each_area > 0:
                files = files[:ptc_num_each_area]

            file_count += len(files)

            # 把files中的文件复制到small_feat_path下
            for file in files:
                file_path = os.path.join(feat_path, file)
                small_file_path = os.path.join(small_feat_path, file)
                os.system(f'cp {file_path} {small_file_path}')
    
    print(file_count/4, "files now in the small dataset.")


def init_label(root, dest):
    areas = os.listdir(root)
    initial_labeled_dic = {}
    init_points = 0
    all_points = 0

    for area in ['Area_1', 'Area_2', 'Area_3', 'Area_4', 'Area_6']:
        area_path = os.path.join(root, area)
        coords_path = os.path.join(area_path, 'coords')
        coords = os.listdir(coords_path)
        for coord in coords:
            xyz = np.load(os.path.join(coords_path, coord))

            labelled_num_cur_pc = round(len(xyz) * 0.0002)

            init_pts = np.argsort(np.random.rand(xyz.shape[0]))[: labelled_num_cur_pc]

            out = [False] * len(xyz)
            for i in init_pts:
                out[i] = True
                init_points += 1

            all_points += len(xyz)

            pc_name = area + '#' + coord[:-4]

            initial_labeled_dic[pc_name] = out

    # 取dest的父目录
    mkdir(os.path.dirname(dest))

    f1 = open(dest, 'w')
    json.dump(initial_labeled_dic, f1)
    f1.close()
    print(all_points, "points in total, ", init_points, "points are initialized.")


if __name__ == '__main__':
    print("Generating small dataset...")
    generate_small_dataset(root, small_dataset_save_path, ptc_num_each_area=2)
    init_label(small_dataset_save_path, init_labelled_save_path)