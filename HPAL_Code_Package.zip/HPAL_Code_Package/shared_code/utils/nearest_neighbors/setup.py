from setuptools import setup, Extension
from Cython.Build import cythonize
import numpy


extensions = [
    Extension(
        name="nearest_neighbors",
        sources=["knn.pyx", "knn_.cxx"],
        include_dirs=["./", numpy.get_include()],
        language="c++",
        extra_compile_args=["-std=c++11", "-fopenmp"],
        extra_link_args=["-fopenmp"],
    )
]

setup(
    name="KNN NanoFLANN",
    ext_modules=cythonize(extensions, language_level=3),
)
