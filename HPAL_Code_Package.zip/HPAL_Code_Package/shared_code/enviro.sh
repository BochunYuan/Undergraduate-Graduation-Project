# conda create -n HPAL python=3.6 -y
# conda install pytorch==1.8.0 torchvision==0.9.0  cudatoolkit=11.1 -c pytorch -c conda-forge -y
conda install pytorch-scatter -c pyg -y
conda install scikit-learn=0.24.2 -y
conda install pyyaml=5.3.1 -y
conda install tqdm=4.61.1 -y
conda install pandas=1.3.2 -y
conda install pyntcloud -c conda-forge -y
conda install plyfile -c conda-forge -y
conda install cython -y
conda install h5py==2.10.0 -y
pip3 install open3d-python==0.3.0
# pip3 install --upgrade git+https://github.com/mit-han-lab/torchsparse.git@v1.2.0 (depend on libsparsehash-dev)
# install libsparsehash-dev (no sudo permissions):
#       git clone https://github.com/sparsehash/sparsehash.git
#       cd sparsehash
#       ./configure --prefix=/path/you/want/local
#       make
#       make install
#       gedit(vim) ~/.bashrc
#       export CPLUS_INCLUDE_PATH=/path/you/want/local/include
#       source ~/.bashrc
# install libsparsehash-dev (with sudo permissions):
#       sudo apt-get install libsparsehash-dev
# ```
# - Compile cpp-related utils:
# ```shell
# sh compile_op.sh