import numpy as np


def generate_paths(file_list):
    raw_data = []
    for file in file_list:
        # 读取每个csv文件为numpy数组
        raw_data.append(np.loadtxt(file, delimiter=','))
    
    # 读取raw_data各项的行数，并按行数从小到大重新排序
    sorted_data = sorted(raw_data, key=lambda x: x.shape[0])
    
    # 新建一个数组，列数是sorted_data的长度，行数是sorted_data中最大的行数
    # 用0填充这个数组, 且数据类型为int
    l = sorted_data[-1].shape[0]
    data = np.zeros((l, len(sorted_data)), dtype=int)
    for i in range(len(sorted_data)):
        for j in range(l):
            # 查找sorted_data[i]的第j列中等于1的元素的行数
            index = np.where(sorted_data[i][:, j] == 1)[0]
            assert len(index) == 1
            data[j, i] = index[0]

    for i in range(l):
        data[i, len(sorted_data) - 1] = i

    return data

if __name__ == '__main__':
    file_list = ['./labels_ds/l3.csv', './labels_ds/l7.csv', './labels_ds/l20.csv']
    data = generate_paths(file_list)
    print(data)