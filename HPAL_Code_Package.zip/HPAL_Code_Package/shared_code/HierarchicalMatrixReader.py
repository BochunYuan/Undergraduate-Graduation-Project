import os
import numpy as np
import yaml
from os.path import basename, splitext

# modified from reproduced-campus3d.dataset.reader.HierarchicalMatrixReader

def read_h_matrix_file_list(list_file, add_zero=True):
    with open(list_file, 'r') as yf:
        file_list = yaml.load(yf, Loader=yaml.FullLoader)['file_list']
    return HierarchicalMatrixReader(files=file_list, add_zero=add_zero)

class HierarchicalMatrixReader(object):
    def __init__(self, matrices=None, files=None, add_zero=False):
        self.hierarchical_matrices = []
        self.project_matrices = []
        if matrices is not None:
            self.hierarchical_matrices = np.asarray(matrices,
                                                    dtype=object)
        elif files is not None:
            self.load_files(files)
        else:
            raise TypeError('Missing required positional argument: \'matirces\' or \'files\'.')
       
        self.layer_num = len(self.hierarchical_matrices) # =  3
        self.classes_num = np.array([arr.shape[0] for arr in self.hierarchical_matrices])
        # = [3, 6, 13]

        self.sort_matrices(add_zero)
        self.all_valid_h_label = self._cal_valid_path()

    def load_files(self, files):
        self.hierarchical_matrices = np.empty((len(files),), dtype=object)
        for i, f in enumerate(files):
            m = np.loadtxt(f, delimiter=',')
            self.hierarchical_matrices[i] = m

    def sort_matrices(self, add_zero):
       # 通过类别数目排序
       sort_ind = np.argsort(self.classes_num)
       self.hierarchical_matrices = self.hierarchical_matrices[sort_ind]
       self.classes_num = self.classes_num[sort_ind]
       if add_zero: self._matrices_add_zero_label()
       self._all_label_project()

    def _cal_valid_path(self):
        leaf_length = self.classes_num[-1] # = 13
        layer_num = self.layer_num # = 3
        all_valid_path = np.zeros((leaf_length, layer_num), dtype=int)
        for i in range(leaf_length):
            leaf_label = np.array([i], dtype=int)
            for j in range(layer_num):
                all_valid_path[i, j] = self.projet_label(leaf_label, -1, j)
        return all_valid_path

    def get_size(self):
        s = len(self.hierarchical_matrices)
        return (s, s, )
    
    # not used here 
    def _matrices_add_zero_label(self):
        self.classes_num += 1 
        for i, m in enumerate(self.hierarchical_matrices):
            m = np.hstack([np.zeros((m.shape[0], 1)), m])
            add_row = np.zeros((1, m.shape[1]))
            add_row[0, 0] = 1
            self.hierarchical_matrices[i] = np.vstack([add_row, m])
    
    def _project_matrix(self, matrix1, matrix2):
        # M*L1 = L2
        return np.clip(np.dot(matrix1, matrix2.transpose()).transpose(), 0, 1)

    def _all_label_project(self):
        self.project_matrices = np.empty(self.get_size(), dtype=object)
        for i in range(self.project_matrices.shape[0]):
            for j in range(self.project_matrices.shape[1]):
                self.project_matrices[i, j] = \
                    self._project_matrix(self.hierarchical_matrices[i],
                                         self.hierarchical_matrices[j])

    def projet_label(self, labels, input_layer, output_layer, mode='num'):
        if mode == 'one_hot':
            return np.dot(labels, self[input_layer, output_layer])
        else:
            return np.argmax(self[output_layer, input_layer][labels], axis=1)

    def __getitem__(self, item):
        # HM[i, j] 调取投影函数，用于在不同层级之间进行投影
        # HM[i ,j] 即是从第j层到第i层的投影矩阵，HM[i, j] * label[j] = label[i]
        return self.project_matrices[item]
    
if __name__ == '__main__':
    list_files = ['../labels/l3.csv',
                  '../labels/l6.csv',
                  '../labels/l13.csv']
    HM = HierarchicalMatrixReader(files=list_files)
    print("HM.hierarchical_matrices")
    print(HM.hierarchical_matrices)
    print("HM.classes_num")
    print(HM.classes_num)
    print("HM.project_matrices")
    print(HM.project_matrices)
    print("HM[0, 1]")
    print(HM[0, 1])
    print("all valid path")
    print(HM.all_valid_h_label)