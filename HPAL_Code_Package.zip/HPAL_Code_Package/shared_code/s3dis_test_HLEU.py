import os

import numpy as np
import gc

from Mink.dataloader.dataset import Stanford3DDataset
from config import ConfigS3DIS as cfg
from data_base_HLEU import S3DIS
# from HierarchicalMatrixReader import HierarchicalMatrixReader
os.environ['CUDA_VISIBLE_DEVICES'] = str(cfg.gpu)
from Mink.base_agent_HLEU import BaseTrainer as minkNet
from label_reader import generate_paths

# 三层相加，原get_final_prediction函数
def get_final_prediction_addition(val_dataset, prob, valid_h_label):
    dataset_len = val_dataset[0].__len__()
    final_prediction = []
    
    for cloud_id in range(dataset_len):
        # 先获取每个点云的最后一层的概率
        cur_cloud_final_prob = prob[-1][cloud_id]

        # 把每个路径的所有概率相加
        for level in range(cfg.label_level-1):
            cur_cloud_cur_level_prob = prob[level][cloud_id]
            transferred_prob = cur_cloud_cur_level_prob[np.arange(cur_cloud_cur_level_prob.shape[0])[:, None], valid_h_label[level]]
            cur_cloud_final_prob += transferred_prob

        # 选择最大概率的路径作为最终预测
        cur_cloud_final_pred = cur_cloud_final_prob.argmax(1)
        final_prediction.append(cur_cloud_final_pred)
    
    return final_prediction

# 三层相乘
def get_final_prediction_multiplication(val_dataset, prob, valid_h_label):
    dataset_len = val_dataset[0].__len__()
    final_prediction = []
    for cloud_id in range(dataset_len):
        # 先获取每个点云的最后一层的概率
        cur_cloud_final_prob = prob[-1][cloud_id]

        # 把每个路径的所有概率相乘
        for level in range(cfg.label_level - 1):
            cur_cloud_cur_level_prob = prob[level][cloud_id]
            transferred_prob = cur_cloud_cur_level_prob[np.arange(cur_cloud_cur_level_prob.shape[0])[:, None], valid_h_label[level]]
            cur_cloud_final_prob *= transferred_prob  # 改成相乘

        # 选择最大概率的路径作为最终预测
        cur_cloud_final_pred = cur_cloud_final_prob.argmax(1)
        final_prediction.append(cur_cloud_final_pred)

    return final_prediction

def get_final_prediction_weighted_addition(val_dataset, prob, valid_h_label, weights):
    dataset_len = val_dataset[0].__len__()
    final_prediction = []
    for cloud_id in range(dataset_len):
        # 先获取每个点云的最后一层的概率
        cur_cloud_final_prob = prob[-1][cloud_id]

        # 把每个路径的所有概率相加，增加权重
        for level in range(cfg.label_level - 1):
            cur_cloud_cur_level_prob = prob[level][cloud_id]
            transferred_prob = cur_cloud_cur_level_prob[np.arange(cur_cloud_cur_level_prob.shape[0])[:, None], valid_h_label[level]]
            cur_cloud_final_prob += weights[level] * transferred_prob  # 加上权重

        # 选择最大概率的路径作为最终预测
        cur_cloud_final_pred = cur_cloud_final_prob.argmax(1)
        final_prediction.append(cur_cloud_final_pred)

    return final_prediction

def get_final_prediction_weighted_multiplication(val_dataset, prob, valid_h_label, weights):
    dataset_len = val_dataset[0].__len__()
    final_prediction = []
    for cloud_id in range(dataset_len):
        # 先获取每个点云的最后一层的概率
        cur_cloud_final_prob = prob[-1][cloud_id]

        # 把每个路径的所有概率相乘，增加权重
        for level in range(cfg.label_level - 1):
            cur_cloud_cur_level_prob = prob[level][cloud_id]
            transferred_prob = cur_cloud_cur_level_prob[np.arange(cur_cloud_cur_level_prob.shape[0])[:, None], valid_h_label[level]]
            # 使用权重相乘
            cur_cloud_final_prob *= (transferred_prob ** weights[level])

        # 选择最大概率的路径作为最终预测
        cur_cloud_final_pred = cur_cloud_final_prob.argmax(1)
        final_prediction.append(cur_cloud_final_pred)

    return final_prediction


import torch
import torch.nn as nn
import torch.nn.functional as F

class EnhancedAttentionFusion(nn.Module):
    def __init__(self, feature_dim):
        super(EnhancedAttentionFusion, self).__init__()
        # 使用两个全连接层来提取更复杂的特征
        self.fc1 = nn.Linear(feature_dim, 64)
        self.fc2 = nn.Linear(64, 1)
    
    def forward(self, prob_list):
        weights = []
        for prob in prob_list:
            # 假设 prob 的形状是 [num_points, feature_dim]
            prob_tensor = torch.tensor(prob, dtype=torch.float32)
            # 对每一层概率特征取平均，生成 [1, feature_dim] 形式
            feature = torch.mean(prob_tensor, dim=0).unsqueeze(0)
            # 使用全连接层提取复杂特征
            weight = F.relu(self.fc1(feature))
            weight = self.fc2(weight).squeeze()  # 映射到一个标量，作为注意力权重
            weights.append(weight)
        
        # 归一化权重
        weights = torch.stack(weights, dim=0)
        attention_weights = F.softmax(weights, dim=0).detach().numpy()

        # 使用注意力权重进行加权求和
        final_prob = sum(attention_weights[i] * prob_list[i] for i in range(len(prob_list)))
        
        return final_prob

def get_final_prediction_enhanced_attention(val_dataset, prob, valid_h_label):
    # 自动确定 feature_dim，用于初始化 AttentionFusion 类
    feature_dim = prob[-1][0].shape[-1]  # 假设每层最后的概率特征维度相同
    attention_fusion = EnhancedAttentionFusion(feature_dim=feature_dim)
    
    dataset_len = val_dataset[0].__len__()
    final_prediction = []
    for cloud_id in range(dataset_len):
        # 获取每个点云的各层概率
        prob_list = []
        for level in range(cfg.label_level - 1):
            cur_cloud_cur_level_prob = prob[level][cloud_id]
            transferred_prob = cur_cloud_cur_level_prob[np.arange(cur_cloud_cur_level_prob.shape[0])[:, None], valid_h_label[level]]
            prob_list.append(transferred_prob)
        
        # 添加最后一层的概率
        prob_list.append(prob[-1][cloud_id])
        
        # 使用改进后的注意力机制进行加权融合
        cur_cloud_final_prob = attention_fusion(prob_list)
        
        # 选择最大概率的路径作为最终预测
        cur_cloud_final_pred = cur_cloud_final_prob.argmax(1)
        final_prediction.append(cur_cloud_final_pred)

    return final_prediction


# 三层传播
def get_final_prediction_propagation(val_dataset, prob, valid_h_label):
    dataset_len = val_dataset[0].__len__()
    final_prediction = []
    for cloud_id in range(dataset_len):
        # 先获取每个点云的最后一层的概率
        cur_cloud_final_prob = prob[-1][cloud_id]

        # 概率传播
        transferred_probs = []
        for level in range(cfg.label_level-1):
            cur_cloud_cur_level_prob = prob[level][cloud_id]
            transferred_prob = cur_cloud_cur_level_prob[np.arange(cur_cloud_cur_level_prob.shape[0])[:, None], valid_h_label[level]]
            transferred_probs.append(transferred_prob)
        
        transferred_probs.append(prob[-1][cloud_id])
        transferred_probs = np.array(transferred_probs)            

        # 选择最大概率的路径作为最终预测
        cur_cloud_final_pred = cur_cloud_final_prob.argmax(1)
        final_prediction.append(cur_cloud_final_pred)
    
    return final_prediction


def test(dataset, valid_h_label):
    model = []
    val_dataset = []
    model_path = cfg.model_save_dir_teacher
    for i in range(cfg.label_level):
        model.append(minkNet(level=i, args=cfg, dataset=dataset[i], isTeacher=False))
        val_dataset.append(Stanford3DDataset(dataset[i].input_xyz['validation'], dataset[i].input_colors['validation'],
                                    dataset[i].input_labels['validation'], dataset[i].input_names['validation'],
                                    voxel_size=0.05))
        checkpoint_file = os.path.join(model_path, f'level_{i}', f'checkpoint{cfg.max_iter-1}.tar')
        model[i].load_checkpoint(checkpoint_file, 0)
    print('model loaded')

    # 获取三个模型的预测概率
    # probs是三层的list，每一层表示一个label level，每一层也各是list，其中每一项表示一个点云的概率数组
    probs = [model[i].get_predict_prob(val_dataset[i]) for i in range(cfg.label_level)]
    print('probability collected')

    # 生成最终预测结果
    final_prediction = get_final_prediction_addition(val_dataset, probs, valid_h_label)
    print('add all levels')
    # 计算miou
    model[-1].cal_miou_HLEU(final_prediction, val_dataset[-1])

    final_prediction = get_final_prediction_multiplication(val_dataset, probs, valid_h_label)
    print('multiple all levels')
    model[-1].cal_miou_HLEU(final_prediction, val_dataset[-1])
    
    # 测试不同权重的加权加法
    weight_sets = [[0.01, 0.1], [0.2, 0.5], [2, 1.5], [0.1, 0.3]]
    for weights in weight_sets:
        final_prediction = get_final_prediction_weighted_addition(val_dataset, probs, valid_h_label, weights)
        print(f'add all levels with weights {weights}')
        model[-1].cal_miou_HLEU(final_prediction, val_dataset[-1])

    # 测试不同权重的加权乘法
    for weights in weight_sets:
        final_prediction = get_final_prediction_weighted_multiplication(val_dataset, probs, valid_h_label, weights)
        print(f'multiple all levels with weights {weights}')
        model[-1].cal_miou_HLEU(final_prediction, val_dataset[-1])

    final_prediction = get_final_prediction_enhanced_attention(val_dataset, probs, valid_h_label)
    print('enhanced attention fusion')
    model[-1].cal_miou_HLEU(final_prediction, val_dataset[-1])

    final_prediction = get_final_prediction_propagation(val_dataset, probs, valid_h_label)
    print('propagation')
    model[-1].cal_miou_HLEU(final_prediction, val_dataset[-1])
    
    del val_dataset
    del model
    del dataset
    del probs
    gc.collect()

if __name__ == '__main__':
    # load label tree
    label_files = os.listdir(cfg.label_path)
    label_files = [f for f in label_files if f.split('.')[0][-1].isdigit()]
    if len(label_files)  == cfg.label_level:
        file_list = [os.path.join('./labels', f) for f in label_files]
        # HM = HierarchicalMatrixReader(files = file_list)
        valid_h_label = generate_paths(file_list)
    else:
        raise ValueError('The number of label files does not match the number of label levels')
    dataset = []
    valid_h_label_transposed = []
    for i in range(cfg.label_level):
        valid_h_label_ = [x[i] for x in valid_h_label]
        valid_h_label_transposed.append(valid_h_label_)
        dataset.append(S3DIS(5, cfg, valid_h_label_))
        print('label level ', i, ' loaded')
    
    valid_h_label_transposed = np.array(valid_h_label_transposed)
    test(dataset, valid_h_label_transposed)