import copy
import os
import sys
from os.path import exists

for _thread_env_key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    if os.environ.get(_thread_env_key) in (None, '', '0'):
        os.environ[_thread_env_key] = '1'

import numpy as np
from sklearn.neighbors import KDTree
from sklearn.cluster import MiniBatchKMeans
from sklearn.neighbors import KernelDensity  # used in gaui_advanced (shared KDE for Edge)
import time
from typing import Optional

from helper_tool import DataProcessing as DP
from helper_utils import log_out, comput_similarity, distance
from joblib import Parallel, delayed
from config import ConfigS3DIS as cfg


# ---------------------------------------------------------------------------
# Composite global scoring replaces the original GAUI integration stage with a
# strict three-term fusion:
#   composite(x) = ( MI(x) + Rep(x) + Edge(x) ) / 3
# HLEU/RUP is still computed upstream as the hierarchy-aware uncertainty signal
# of the original pipeline. Its original GAUI dot-product output is used as a
# global uncertainty reference to condition each branch, but it is not treated
# as a fourth weighted module inside the composite formula.
# ---------------------------------------------------------------------------

FULL_COMPOSITE_METHODS = ('HLEU', 'HLEU_delete_dot')
HLEU_SCORING_METHODS = FULL_COMPOSITE_METHODS + ('HLEU_MI_only',)

def _minmax_norm(x: np.ndarray) -> np.ndarray:
    """Min-max normalise to [0, 1]; returns zeros if range is zero."""
    lo, hi = x.min(), x.max()
    if hi - lo < 1e-12:
        return np.zeros_like(x, dtype=np.float64)
    return (x - lo) / (hi - lo)


def compute_mi_score(mc_array: np.ndarray) -> np.ndarray:
    """
    Compute BALD mutual information from real MC Dropout predictions.

    Uses T independent stochastic forward passes (Dropout active) whose
    softmax outputs are saved by test_prob_savememory as a (T, N, C) array.
    No offline simulation is needed.

    BALD formulation:
        MI(x) = H[E_w[p(x)]] - E_w[H[p(x)]]
    where H is the Shannon entropy and the expectation is over T draws.

    Parameters
    ----------
    mc_array : (T, N, C) softmax probabilities from T MC Dropout forward passes.

    Returns
    -------
    mi : (N,) mutual information scores (non-negative).
    """
    eps = 1e-12

    # Predictive entropy: H[E_w[p]]
    mean_prob = mc_array.mean(axis=0)                                          # (N, C)
    predictive_entropy = -np.sum(mean_prob * np.log(mean_prob + eps), axis=1) # (N,)

    # Expected entropy: E_w[H[p]]
    per_sample_entropy = -np.sum(mc_array * np.log(mc_array + eps), axis=2)   # (T, N)
    expected_entropy = per_sample_entropy.mean(axis=0)                         # (N,)

    mi = np.maximum(predictive_entropy - expected_entropy, 0.0)
    return mi


def compute_rep_score(
    features: np.ndarray,
    n_clusters: int,
    fit_features: Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Representativeness score: cosine similarity between each point and its
    assigned KMeans cluster centre.

    score_rep(x) = cos_sim(f(x), c_k(x))  mapped to [0, 1]

    Points that closely resemble a cluster prototype receive high scores,
    ensuring that annotated samples cover diverse, salient feature-space
    regions rather than clustering in a narrow area.

    Parameters
    ----------
    features   : (N, D) feature vectors (e.g. MinkUNet decoder output).
    n_clusters : number of KMeans clusters; clamped to min(k, N//4).

    Returns
    -------
    rep : (N,) representativeness scores in [0, 1].
    """
    N, D = features.shape
    eps = 1e-12

    if fit_features is None:
        fit_features = features

    # Clamp n_clusters to avoid degenerate cases with very small clouds
    k = min(n_clusters, max(1, N // 4))

    # Mini-Batch KMeans clustering
    km = MiniBatchKMeans(n_clusters=k, random_state=0, n_init=3)
    km.fit(fit_features)
    labels = km.predict(features)
    centres = km.cluster_centers_  # (k, D)

    # Cosine similarity to the assigned cluster centre, mapped to [0, 1]
    f_norm = features / (np.linalg.norm(features, axis=1, keepdims=True) + eps)
    c_norm = centres / (np.linalg.norm(centres, axis=1, keepdims=True) + eps)
    cos_sim = np.sum(f_norm * c_norm[labels], axis=1)       # (N,)  in [-1, 1]
    rep = np.clip((cos_sim + 1.0) / 2.0, 0.0, 1.0)         # (N,)  in [ 0, 1]

    return rep


def compute_edge_score(local_density: np.ndarray, xyz: np.ndarray,
                       eps: float = 1e-6, beta: float = 1.0) -> np.ndarray:
    """
    Edge / Rarity score: rewards points in sparse, geometrically complex regions.

    Base rarity  = 1 / (local_density + eps)
    Gradient aug = multiply by (1 + beta * GradMag(x))
    where GradMag approximates local normal variation via the std of xyz in a
    small KNN neighbourhood (k=8).

    The local_density is computed once externally (in gaui_advanced via KDE)
    and shared here to avoid redundant O(N²) KDE computation.

    Parameters
    ----------
    local_density : (N,) per-point feature-space density from a shared KDE.
    xyz           : (N, 3) point coordinates for geometric gradient.
    eps           : floor constant to avoid division by zero.
    beta          : gradient enhancement strength.

    Returns
    -------
    edge : (N,) edge/rarity scores (before normalisation).
    """
    N = local_density.shape[0]

    base_rarity = 1.0 / (local_density + eps)

    # Geometric gradient: std of xyz coordinates in k-NN (k=8)
    k_geo = min(8, N - 1)
    if k_geo > 0:
        kd = KDTree(xyz)
        _, nn_idx = kd.query(xyz, k=k_geo + 1)       # first neighbour is the point itself
        nn_idx = nn_idx[:, 1:]                         # (N, k)
        local_xyz_std = xyz[nn_idx].std(axis=(1, 2))  # (N,)
        grad_mag = _minmax_norm(local_xyz_std)
    else:
        grad_mag = np.zeros(N, dtype=np.float64)

    edge = base_rarity * (1.0 + beta * grad_mag)
    return edge


def _subsample_fit_features(features: np.ndarray, cfg_obj) -> np.ndarray:
    max_points = int(getattr(cfg_obj, 'gaui_adv_fit_max_points', 0))
    if max_points <= 0 or len(features) <= max_points:
        return features

    rng = np.random.default_rng(getattr(cfg_obj, 'gaui_adv_fit_sample_seed', 0))
    sample_idx = rng.choice(len(features), size=max_points, replace=False)
    return features[sample_idx]


def gaui_advanced(
    hleu_value: np.ndarray,
    mc_array: np.ndarray,
    features: np.ndarray,
    xyz: np.ndarray,
    cfg_obj,
) -> np.ndarray:
    """
    Strict three-part composite scoring.

    HLEU/RUP is accepted as the upstream hierarchy-aware uncertainty context of
    the original pipeline. The original GAUI dot-product signal conditions each
    branch before fusion, but the composite module itself is built only from:
      1. MI   : epistemic uncertainty / knowledge gain
      2. Rep  : feature-space representativeness
      3. Edge : rarity / geometric boundary emphasis

    Each term is normalised independently and then fused with equal weight.

    Returns a point-level score following the project convention:
    smaller score = more informative point.
    """
    fit_features = _subsample_fit_features(features, cfg_obj)
    N_fit, D = fit_features.shape

    # Keep the hierarchy-aware input in the interface and validate alignment
    # with the current cloud. This is the original GAUI global reference signal,
    # used to condition each branch rather than being fused as a fourth branch.
    hleu_value = np.asarray(hleu_value, dtype=np.float64)
    if hleu_value.ndim != 1 or len(hleu_value) != len(features):
        raise ValueError(
            f"HLEU value shape mismatch: expected ({len(features)},), got {hleu_value.shape}"
        )
    hleu_ref = _minmax_norm(hleu_value)

    # --- Shared KDE (computed once, reused by Edge) ---
    bw = max(fit_features.std() * N_fit ** (-1.0 / (D + 4)), 1e-3)
    kde = KernelDensity(kernel='gaussian', bandwidth=float(bw))
    kde.fit(fit_features)
    local_density = np.exp(kde.score_samples(features))

    # --- MI: real MC Dropout predictions -> BALD ---
    mi_norm = _minmax_norm(compute_mi_score(mc_array) * hleu_ref)

    # --- Rep: KMeans + cosine similarity ---
    rep_norm = _minmax_norm(compute_rep_score(
        features,
        n_clusters=cfg_obj.gaui_adv_rep_n_clusters,
        fit_features=fit_features,
    ) * hleu_ref)

    # --- Edge: shared local_density + geometric gradient ---
    edge_norm = _minmax_norm(compute_edge_score(
        local_density,
        xyz,
        eps=cfg_obj.gaui_adv_edge_eps,
    ) * hleu_ref)

    composite = (mi_norm + rep_norm + edge_norm) / 3.0
    composite_norm = _minmax_norm(composite)
    return 1.0 - composite_norm


def gaui_mi_only(hleu_value: np.ndarray, mc_array: np.ndarray) -> np.ndarray:
    """
    Ablation scorer that keeps only the MI branch while preserving the same
    HLEU/RUP conditioning and point-score convention as the full composite path.
    """
    hleu_value = np.asarray(hleu_value, dtype=np.float64)
    if hleu_value.ndim != 1:
        raise ValueError(f"HLEU value must be 1D, got shape {hleu_value.shape}")
    if mc_array.ndim != 3 or mc_array.shape[1] != len(hleu_value):
        raise ValueError(
            f"MC probability shape mismatch: expected (T,{len(hleu_value)},C), got {mc_array.shape}"
        )

    hleu_ref = _minmax_norm(hleu_value)
    mi_only = _minmax_norm(compute_mi_score(mc_array) * hleu_ref)
    return 1.0 - mi_only

# 获取特定点云中某点坐标数据
def get_xyz(cloud_idx, pt_idx, dataset):
    xyz = np.load(dataset.input_xyz['train'][cloud_idx])
    pt_xyz = xyz[pt_idx]
    pt_xyz_return = copy.deepcopy(pt_xyz)
    return pt_xyz_return

# 获取特定点云中某点颜色
def get_feature(path, pt_idx):
    feature = np.load(path)
    feature_cur = feature[pt_idx]
    feature_cur_return = copy.deepcopy(feature_cur)
    return feature_cur_return

def get_parent_and_brother_indexes(level, label, all_valid_h_label):
    par_index = all_valid_h_label[np.where(all_valid_h_label[:, level] == label)[0]][0][level - 1]
    bro_indexes_path = np.where(all_valid_h_label[:, level - 1] == par_index)[0]
    bro_indexes = np.unique(all_valid_h_label[bro_indexes_path, level])
    return par_index, bro_indexes

def calculate_uncert_for_point_with_uncert(point, level, uncert, prob, mlevel_uncert, all_valid_h_label):
    if point % 5000 == 0:
        print(f"point {point} start")
    cur_level_point_uncert = np.zeros_like(uncert[level][point])
    for label in range(len(uncert[level][0])):
        # print(f"point {point} label {label} start")
        par_index, bro_indexes = get_parent_and_brother_indexes(
            level, label, all_valid_h_label)
        cur_level_point_label_uncert = (
            mlevel_uncert[level-1][point][par_index] * uncert[level][point][label] * 0.5
            / (np.sum(uncert[level][point][bro_indexes]) + 1e-12)
            + uncert[level][point][label]
        )
        cur_level_point_uncert[label] = cur_level_point_label_uncert
        # print(f"point {point} label {label} finish")
    return cur_level_point_uncert

def calculate_uncert_for_point_with_prob(point, level, uncert, prob, mlevel_uncert, all_valid_h_label):
    if point % 5000 == 0:
        print(f"point {point} start")
    cur_level_point_uncert = np.zeros_like(uncert[level][point])
    for label in range(len(uncert[level][0])):
        # print(f"point {point} label {label} start")
        par_index, bro_indexes = get_parent_and_brother_indexes(
            level, label, all_valid_h_label)
        cur_level_point_label_uncert = (
            mlevel_uncert[level-1][point][par_index] * prob[level][point][label] * 0.5
            / (np.sum(prob[level][point][bro_indexes]) + 1e-12)
            + uncert[level][point][label]
        )
        cur_level_point_uncert[label] = cur_level_point_label_uncert
        # print(f"point {point} label {label} finish")
    return cur_level_point_uncert

def _aggregate_scores_by_projection(score: np.ndarray, projection: np.ndarray, output_size: int) -> np.ndarray:
    sums = np.bincount(projection, weights=score, minlength=output_size)
    counts = np.bincount(projection, minlength=output_size)
    return sums / np.maximum(counts, 1)


def _propagate_multiscale_scores(base_score: np.ndarray, xyz: np.ndarray, grid_levels) -> np.ndarray:
    score_multi_level = [np.asarray(base_score, dtype=np.float32)]
    proj_multi_level = []
    coords = xyz

    for lev in grid_levels:
        coords_sub = DP.grid_sub_sampling(coords, grid_size=lev)
        search_tree_sub = KDTree(coords_sub)
        proj_index_to_origin = np.squeeze(
            search_tree_sub.query(coords, return_distance=False)
        ).astype(np.int64, copy=False)

        score_multi_level.append(
            _aggregate_scores_by_projection(
                score_multi_level[-1],
                proj_index_to_origin,
                len(coords_sub),
            )
        )
        proj_multi_level.append(proj_index_to_origin)
        coords = coords_sub

    for i_proj_back in range(len(proj_multi_level) - 1, -1, -1):
        proj = proj_multi_level[i_proj_back]
        score_multi_level[i_proj_back] = (
            score_multi_level[i_proj_back]
            + 0.1 * score_multi_level[i_proj_back + 1][proj]
        )

    return score_multi_level[0]


def _load_mc_probs(cfg, cloud_name, deterministic_prob):
    cur_path_mc_probs = os.path.join(
        cfg.save_path_probs,
        f"level_{cfg.label_level - 1}",
        f"{cloud_name}_mc.npy",
    )
    if os.path.exists(cur_path_mc_probs):
        return np.load(cur_path_mc_probs).astype(np.float32, copy=False)

    # Backward compatibility for old outputs: a (T, N, C) file may have been
    # saved directly as cloud.npy. If only deterministic probabilities exist,
    # fall back to a singleton MC axis so MI becomes zero instead of crashing.
    if deterministic_prob.ndim == 3:
        return deterministic_prob.astype(np.float32, copy=False)
    return deterministic_prob[None, ...].astype(np.float32, copy=False)


def _load_level_probs(cfg, cloud_name):
    probs = []
    for level in range(cfg.label_level):
        cur_path_probs = os.path.join(
            cfg.save_path_probs,
            f"level_{level}",
            f"{cloud_name}.npy",
        )
        probs.append(np.load(cur_path_probs).astype(np.float32, copy=False))
    return probs


def _calculate_hleu_value(cfg, prob, all_valid_h_label):
    """Original HLEU/RUP hierarchy-aware point signal before GAUI replacement."""
    uncert = [1 - np.abs(p - 0.5) * 2 for p in prob]
    mlevel_uncert = [uncert[0]]

    if cfg.propagate_with_uncert:
        for level in range(1, len(uncert)):
            print(f"level {level}")
            cur_level_uncert = []
            for point in range(len(uncert[level])):
                result = calculate_uncert_for_point_with_uncert(
                    point,
                    level,
                    uncert,
                    prob,
                    mlevel_uncert,
                    all_valid_h_label,
                )
                cur_level_uncert.append(result)
            mlevel_uncert.append(np.asarray(cur_level_uncert))
            print(f"level {level} finished")
    else:
        for level in range(1, len(uncert)):
            print(f"level {level}")
            cur_level_uncert = []
            for point in range(len(uncert[level])):
                result = calculate_uncert_for_point_with_prob(
                    point,
                    level,
                    uncert,
                    prob,
                    mlevel_uncert,
                    all_valid_h_label,
                )
                cur_level_uncert.append(result)
            mlevel_uncert.append(np.asarray(cur_level_uncert))
            print(f"level {level} finished")

    avg_uncert = [np.nanmean(level_uncert, axis=0) for level_uncert in mlevel_uncert]
    hleu_value = np.dot(mlevel_uncert[-1], avg_uncert[-1])
    return _minmax_norm(hleu_value)


def scoring(cfg, i, method, dataset, all_valid_h_label):
    xyz = np.load(dataset.input_xyz['train'][i])
    cloud_name = dataset.input_names['train'][i]

    if method == 'random':
        score_pt = np.random.rand(xyz.shape[0])
    elif method in HLEU_SCORING_METHODS:
        prob = _load_level_probs(cfg, cloud_name)
        for level, prob_level in enumerate(prob):
            if len(xyz) != len(prob_level):
                raise ValueError(
                    f"Probability length mismatch for {cloud_name} level {level}: "
                    f"xyz={len(xyz)}, prob={len(prob_level)}"
                )

        hleu_value = _calculate_hleu_value(cfg, prob, all_valid_h_label)

        mc_array = _load_mc_probs(cfg, cloud_name, prob[-1])
        if mc_array.ndim != 3 or mc_array.shape[1] != len(xyz):
            raise ValueError(
                f"MC probability shape mismatch for {cloud_name}: "
                f"expected (T,{len(xyz)},C), got {mc_array.shape}"
            )

        if method in FULL_COMPOSITE_METHODS:
            cur_path_feat = os.path.join(
                cfg.save_path_feat,
                f"level_{cfg.label_level - 1}",
                f"{cloud_name}.npy",
            )
            features = np.load(cur_path_feat).astype(np.float32, copy=False)
            if len(features) != len(xyz):
                raise ValueError(
                    f"Feature length mismatch for {cloud_name}: "
                    f"xyz={len(xyz)}, feat={len(features)}"
                )

            base_score = gaui_advanced(hleu_value, mc_array, features, xyz, cfg)
        elif method == 'HLEU_MI_only':
            base_score = gaui_mi_only(hleu_value, mc_array)
        else:
            raise ValueError(f'Unsupported HLEU scoring variant: {method}')

        score_pt = _propagate_multiscale_scores(
            base_score,
            xyz,
            getattr(cfg, 'score_grid_levels', (0.1, 0.5, 1.0)),
        )
        print(f"point cloud {i} finish scoring")
    else:
        raise ValueError(f'Unsupported active strategy for HLEU scoring: {method}')

    return np.asarray(score_pt)

def score_single_cloud(i, dataset, method, cfg, all_valid_h_label):
    score_pt = scoring(cfg, i, method, dataset, all_valid_h_label)
    score_region = np.empty((len(score_pt), 3), dtype=np.float64)
    score_region[:, 0] = score_pt
    score_region[:, 1] = i
    score_region[:, 2] = np.arange(len(score_pt), dtype=np.float64)
    return score_region


def calculate_score(dataset, method, cfg, log_file, all_valid_h_label):
    t0 = time.time()
    log_out('[Main]' + '	' + ' start scoring', log_file)
    dataset_fine = dataset[cfg.label_level - 1]
    num_val = len(dataset_fine.input_labels['train'])

    n_jobs = min(max(1, getattr(cfg, 'score_parallel_jobs', 12)), num_val)
    score_list = Parallel(n_jobs=n_jobs, backend='multiprocessing', batch_size='auto')(
        delayed(score_single_cloud)(i, dataset_fine, method, cfg, all_valid_h_label) for i in range(num_val)
    )

    score_final = np.vstack(score_list)
    score_final = score_final[np.argsort(score_final[:, 1])]
    score_sort = np.argsort(score_final[:, 0])
    score_final = score_final[score_sort]

    t1 = time.time()
    log_out('[Main]' + '	' + ' scoring time:' + str(t1 - t0), log_file)
    return score_final


def method_requires_probs(method: str) -> bool:
    return method in HLEU_SCORING_METHODS


def method_requires_features(method: str) -> bool:
    # Finest-level features are still needed by active_chose() for FDS.
    return method in HLEU_SCORING_METHODS


def method_requires_mc_probs(method: str) -> bool:
    return method in HLEU_SCORING_METHODS


def generate_score(cfg, model_student, dataset, pool_dataset, log_file, all_valid_h_label):
    if cfg.active_strategy in HLEU_SCORING_METHODS:
        resolved_levels = list(range(cfg.label_level))
    else:
        required_levels = getattr(cfg, 'score_required_levels', (-1,))
        resolved_levels = []
        for level in required_levels:
            resolved_level = cfg.label_level - 1 if level == -1 else level
            if 0 <= resolved_level < cfg.label_level:
                resolved_levels.append(resolved_level)
        resolved_levels = sorted(set(resolved_levels))
        if not resolved_levels:
            resolved_levels = [cfg.label_level - 1]

    save_probs = method_requires_probs(cfg.active_strategy)
    save_feats = method_requires_features(cfg.active_strategy)
    save_mc_probs = method_requires_mc_probs(cfg.active_strategy)
    finest_level = cfg.label_level - 1
    for level in resolved_levels:
        model_student[level].test_prob_savememory(
            pool_dataset[level],
            save_probs=save_probs,
            save_feats=save_feats and level == finest_level,
            save_mc_probs=save_mc_probs and level == finest_level,
        )

    return calculate_score(
        dataset,
        method=cfg.active_strategy,
        cfg=cfg,
        log_file=log_file,
        all_valid_h_label=all_valid_h_label,
    )


def active_chose(cfg, score_final, dataset, log_file):
    score_idx = 0
    count = 0
    start1 = time.time()

    chosen_features = []
    chosen_cloud_idx = []
    chosen_xyz = []

    # There are two methods can be used for points selection:
    # 0.Select top-k points from all point clouds
    ####################################################
    while count < round(len(score_final) * (cfg.chosen_rate_AL / 100)):
        cloud_idx = score_final[score_idx][1].astype('int')
        cloud_name = dataset[-1].input_names['train'][cloud_idx]
        pt_idx = score_final[score_idx][-1].astype('int')

        pt_xyz = get_xyz(cloud_idx, pt_idx, dataset[-1])

        # already labeled
        if dataset[-1].labeled_points[cloud_name][pt_idx]:
            score_idx += 1
            continue

        # FDS
        is_chosen = False
        cur_path_feat = os.path.join(cfg.save_path_feat,'level_' + str(cfg.label_level-1), cloud_name + '.npy')
        feature_cur = get_feature(cur_path_feat, pt_idx)
        for idx_, feature in enumerate(chosen_features):
            if chosen_cloud_idx[idx_] == cloud_idx and distance(pt_xyz, chosen_xyz[idx_]) < 0.2 and comput_similarity(
                    feature_cur, feature) > 0.8:
                is_chosen = True
                break
        if is_chosen:
            score_idx += 1
            continue
        chosen_features.append(feature_cur)
        chosen_cloud_idx.append(cloud_idx)
        chosen_xyz.append(pt_xyz)

        for i in range(cfg.label_level):
            dataset[i].labeled_points[cloud_name][pt_idx] = True

        count += 1

        score_idx += 1
    ####################################################

    # 1.each point cloud selects a fixed number of points (like ScanNet benchmark)
    # Our 0.02% budget in S3DIS is completed by using 20pts
    ####################################################
    # chosen_pt_perpc = [0] * len(dataset.input_xyz['train'])
    # per_pc_limit = cfg.chosen_points_per_pc
    # num_pt_perpc = [per_pc_limit] * len(dataset.input_xyz['train'])
    # while count < per_pc_limit * len(dataset.input_xyz['train']):
    #     cloud_idx = score_final[score_idx][1].astype('int')
    #
    #     if chosen_pt_perpc[cloud_idx] >= num_pt_perpc[cloud_idx]:
    #         score_idx += 1
    #         continue
    #
    #     cloud_name = dataset.input_names['train'][cloud_idx]
    #     pt_idx = score_final[score_idx][2].astype('int')
    #     pt_xyz = get_xyz(cloud_idx, pt_idx, dataset)
    #
    #     if dataset.labeled_points[cloud_name][pt_idx]:
    #         score_idx += 1
    #         continue
    #
    #     # FDS
    #     is_chosen = False
    #     cur_path_feat = os.path.join(cfg.save_path_feat, cloud_name + '.npy')
    #     feature_cur = get_feature(cur_path_feat, pt_idx)
    #     for idx_, feature in enumerate(chosen_features):
    #         if chosen_cloud_idx[idx_] == cloud_idx and distance(pt_xyz, chosen_xyz[idx_]) < 0.2 and comput_similarity(
    #                 feature_cur, feature) > 0.8:
    #             is_chosen = True
    #             break
    #     if is_chosen:
    #         score_idx += 1
    #         continue
    #     chosen_features.append(feature_cur)
    #     chosen_cloud_idx.append(cloud_idx)
    #     chosen_xyz.append(pt_xyz)
    #
    #     dataset.labeled_points[cloud_name][pt_idx] = True
    #     chosen_pt_perpc[cloud_idx] += 1
    #     count += 1
    #     score_idx += 1
    ####################################################

    end2 = time.time()
    print('[Main]' + '\t'+ ' AL time:' + str(end2 - start1))
