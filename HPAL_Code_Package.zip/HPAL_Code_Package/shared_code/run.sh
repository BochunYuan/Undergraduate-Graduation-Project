# Check if conda is initialized
if ! grep -q "conda initialize" ~/.bashrc; then
    conda init
    # Reload the shell to apply changes
    source ~/.bashrc
fi

# Activate the environment
conda activate HPAL

# Run the Python script
python s3dis_main_HLEU.py --test_area 5 --mode AL_train